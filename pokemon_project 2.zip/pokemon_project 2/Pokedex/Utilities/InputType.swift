import Foundation

enum InputType {
    case none
    case text
    case number
    case select
}
