import Foundation

struct NameDataPair: Codable {
    let name: String
    let data: Data
}
